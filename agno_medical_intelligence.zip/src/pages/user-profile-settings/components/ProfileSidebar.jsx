import React from 'react';
import Icon from '../../../components/AppIcon';

const ProfileSidebar = ({ activeSection, onSectionChange }) => {
  const sidebarSections = [
    {
      id: 'personal',
      label: 'Personal Information',
      icon: 'User',
      description: 'Basic profile and professional details'
    },
    {
      id: 'credentials',
      label: 'Medical Credentials',
      icon: 'Award',
      description: 'Licenses and certifications'
    },
    {
      id: 'security',
      label: 'Security Settings',
      icon: 'Shield',
      description: 'Password and authentication'
    },
    {
      id: 'notifications',
      label: 'Notification Preferences',
      icon: 'Bell',
      description: 'Email and push notifications'
    },
    {
      id: 'privacy',
      label: 'Privacy Controls',
      icon: 'Lock',
      description: 'Data sharing and privacy'
    }
  ];

  return (
    <div className="w-full lg:w-80 space-y-2">
      <div className="bg-card border border-border rounded-lg p-4 shadow-card mb-6">
        <div className="flex items-center space-x-3 mb-4">
          <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center">
            <Icon name="User" size={24} color="white" />
          </div>
          <div>
            <h3 className="font-heading font-semibold text-card-foreground">Dr. Sarah Chen</h3>
            <p className="text-sm text-muted-foreground">Cardiologist</p>
          </div>
        </div>
        <div className="flex items-center space-x-2 text-sm">
          <Icon name="Shield" size={14} className="text-success" />
          <span className="text-success font-medium">Verified Professional</span>
        </div>
      </div>

      <nav className="space-y-1">
        {sidebarSections.map((section) => (
          <button
            key={section.id}
            onClick={() => onSectionChange(section.id)}
            className={`w-full flex items-start space-x-3 p-4 rounded-lg text-left transition-colors duration-200 ${
              activeSection === section.id
                ? 'bg-accent text-accent-foreground'
                : 'text-foreground hover:bg-muted'
            }`}
          >
            <Icon 
              name={section.icon} 
              size={20} 
              className={activeSection === section.id ? 'text-accent-foreground' : 'text-muted-foreground'} 
            />
            <div className="flex-1">
              <h3 className="font-body font-medium text-sm">
                {section.label}
              </h3>
              <p className={`text-xs mt-1 ${
                activeSection === section.id 
                  ? 'text-accent-foreground/80' 
                  : 'text-muted-foreground'
              }`}>
                {section.description}
              </p>
            </div>
            {activeSection === section.id && (
              <Icon name="ChevronRight" size={16} className="text-accent-foreground" />
            )}
          </button>
        ))}
      </nav>

      {/* Quick Stats */}
      <div className="bg-card border border-border rounded-lg p-4 shadow-card mt-6">
        <h3 className="font-heading font-medium text-card-foreground mb-3">
          Account Status
        </h3>
        <div className="space-y-3">
          <div className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground">Profile Completion</span>
            <span className="font-medium text-success">95%</span>
          </div>
          <div className="w-full bg-muted rounded-full h-2">
            <div className="bg-success h-2 rounded-full" style={{ width: '95%' }}></div>
          </div>
          
          <div className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground">Cases Submitted</span>
            <span className="font-medium text-card-foreground">24</span>
          </div>
          
          <div className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground">Last Login</span>
            <span className="font-medium text-card-foreground">Today</span>
          </div>
        </div>
      </div>

      {/* Security Status */}
      <div className="bg-card border border-border rounded-lg p-4 shadow-card">
        <h3 className="font-heading font-medium text-card-foreground mb-3">
          Security Status
        </h3>
        <div className="space-y-2">
          <div className="flex items-center space-x-2 text-sm">
            <Icon name="Check" size={14} className="text-success" />
            <span className="text-success">Two-Factor Authentication</span>
          </div>
          <div className="flex items-center space-x-2 text-sm">
            <Icon name="Check" size={14} className="text-success" />
            <span className="text-success">Strong Password</span>
          </div>
          <div className="flex items-center space-x-2 text-sm">
            <Icon name="Check" size={14} className="text-success" />
            <span className="text-success">Email Verified</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProfileSidebar;
import React, { useState, useEffect } from 'react';

// Mock user info
const mockUser = {
  id: 'user-1',
  name: 'Dr. Jane Doe',
};

// Helper to generate unique IDs for comments
const generateId = () => '_' + Math.random().toString(36).substr(2, 9);

// Helper to get initials from name
const getInitials = (name) => {
  return name
    .split(' ')
    .map((n) => n[0])
    .join('')
    .toUpperCase();
};

const LOCAL_STORAGE_KEY = 'agno_case_comments';

const loadComments = () => {
  try {
    const data = localStorage.getItem(LOCAL_STORAGE_KEY);
    return data ? JSON.parse(data) : {};
  } catch {
    return {};
  }
};

const saveComments = (commentsByCase) => {
  try {
    localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(commentsByCase));
  } catch {}
};

export default function CommentSection({ caseId }) {
  const [commentsByCase, setCommentsByCase] = useState({});
  const [input, setInput] = useState('');
  const [posting, setPosting] = useState(false);

  // Load comments from localStorage on mount
  useEffect(() => {
    setCommentsByCase(loadComments());
  }, []);

  // Save comments to localStorage whenever they change
  useEffect(() => {
    saveComments(commentsByCase);
  }, [commentsByCase]);

  const comments = commentsByCase[caseId] || [];

  const handlePost = (e) => {
    e.preventDefault();
    if (!input.trim()) return;
    setPosting(true);
    const newComment = {
      id: generateId(),
      userId: mockUser.id,
      userName: mockUser.name,
      content: input.trim(),
      timestamp: new Date().toISOString(),
    };
    setCommentsByCase((prev) => ({
      ...prev,
      [caseId]: [...(prev[caseId] || []), newComment],
    }));
    setInput('');
    setPosting(false);
  };

  // Format timestamp nicely
  const formatTimestamp = (iso) => {
    const date = new Date(iso);
    return date.toLocaleString(undefined, {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  return (
    <div className="bg-white rounded shadow p-4 mt-8">
      <h3 className="text-lg font-semibold mb-4">Case Discussion</h3>
      <form onSubmit={handlePost} className="flex gap-2 mb-4">
        <input
          type="text"
          className="flex-1 border rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-200"
          placeholder="Add a comment..."
          value={input}
          onChange={(e) => setInput(e.target.value)}
          disabled={posting}
        />
        <button
          type="submit"
          className="bg-blue-600 text-white px-4 py-2 rounded disabled:opacity-50 hover:bg-blue-700 transition"
          disabled={posting || !input.trim()}
        >
          Post
        </button>
      </form>
      <div className="space-y-3">
        {comments.length === 0 ? (
          <div className="text-gray-500">No comments yet. Be the first to comment!</div>
        ) : (
          comments.map((comment, idx) => (
            <div
              key={comment.id}
              className={
                `flex items-start gap-3 pb-3 ${idx !== comments.length - 1 ? 'border-b border-gray-200' : ''} hover:bg-gray-50 rounded transition`
              }
            >
              <div className="flex-shrink-0 w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center text-blue-700 font-bold text-lg">
                {getInitials(comment.userName)}
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <span className="font-medium text-sm">{comment.userName}</span>
                  <span className="text-xs text-gray-400">{formatTimestamp(comment.timestamp)}</span>
                </div>
                <div className="text-gray-800 mt-1 text-base">{comment.content}</div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
} 
import openai from './openaiClient';

/**
 * OpenAI Service for AGNO Medical Intelligence Platform
 * Provides AI-powered medical analysis and diagnostic assistance
 */

/**
 * Analyzes symptoms and provides ICD-10 code suggestions
 * @param {string} symptomDescription - Description of symptoms
 * @returns {Promise<object>} Structured response with symptom analysis and ICD-10 suggestions
 */
export async function analyzeSymptoms(symptomDescription) {
  try {
    const response = await openai.chat.completions.create({
      model: 'gpt-4o',
      messages: [
        {
          role: 'system',
          content: `You are a medical AI assistant specializing in symptom analysis and ICD-10 code suggestions. 
          You provide accurate, evidence-based medical insights for healthcare professionals.
          Always include relevant ICD-10 codes and prioritize rare or unusual conditions when appropriate.`
        },
        {
          role: 'user',
          content: `Analyze these symptoms and provide ICD-10 code suggestions: ${symptomDescription}`
        }
      ],
      response_format: {
        type: 'json_schema',
        json_schema: {
          name: 'symptom_analysis',
          schema: {
            type: 'object',
            properties: {
              suggestions: {
                type: 'array',
                items: {
                  type: 'object',
                  properties: {
                    symptom: { type: 'string' },
                    icd10_code: { type: 'string' },
                    description: { type: 'string' },
                    confidence: { type: 'number' },
                    category: { type: 'string' }
                  },
                  required: ['symptom', 'icd10_code', 'description', 'confidence', 'category']
                }
              },
              rare_disease_indicators: {
                type: 'array',
                items: {
                  type: 'object',
                  properties: {
                    indicator: { type: 'string' },
                    significance: { type: 'string' },
                    requires_attention: { type: 'boolean' }
                  },
                  required: ['indicator', 'significance', 'requires_attention']
                }
              },
              clinical_notes: { type: 'string' }
            },
            required: ['suggestions', 'rare_disease_indicators', 'clinical_notes'],
            additionalProperties: false
          }
        }
      }
    });

    return JSON.parse(response.choices[0].message.content);
  } catch (error) {
    console.error('Error analyzing symptoms:', error);
    return {
      suggestions: [],
      rare_disease_indicators: [],
      clinical_notes: 'Unable to analyze symptoms at this time. Please try again.'
    };
  }
}

/**
 * Provides diagnostic insights based on complete case information
 * @param {object} caseData - Complete case data including symptoms, timeline, demographics
 * @returns {Promise<object>} Structured diagnostic insights
 */
export async function generateDiagnosticInsights(caseData) {
  try {
    const caseDescription = `
      Patient Demographics: ${caseData.demographics || 'Not provided'}
      Primary Symptoms: ${caseData.symptoms || 'Not provided'}
      Timeline: ${caseData.timeline || 'Not provided'}
      Clinical Notes: ${caseData.clinicalNotes || 'Not provided'}
    `;

    const response = await openai.chat.completions.create({
      model: 'gpt-4o',
      messages: [
        {
          role: 'system',
          content: `You are a senior medical diagnostician AI assistant. Analyze medical cases and provide 
          comprehensive diagnostic insights, differential diagnoses, and recommendations for further investigation.
          Focus on rare diseases and unusual presentations when patterns suggest them.`
        },
        {
          role: 'user',
          content: `Provide diagnostic insights for this medical case: ${caseDescription}`
        }
      ],
      response_format: {
        type: 'json_schema',
        json_schema: {
          name: 'diagnostic_insights',
          schema: {
            type: 'object',
            properties: {
              primary_diagnosis: {
                type: 'object',
                properties: {
                  diagnosis: { type: 'string' },
                  icd10_code: { type: 'string' },
                  confidence: { type: 'number' },
                  rationale: { type: 'string' }
                },
                required: ['diagnosis', 'icd10_code', 'confidence', 'rationale']
              },
              differential_diagnoses: {
                type: 'array',
                items: {
                  type: 'object',
                  properties: {
                    diagnosis: { type: 'string' },
                    icd10_code: { type: 'string' },
                    probability: { type: 'number' },
                    reasoning: { type: 'string' }
                  },
                  required: ['diagnosis', 'icd10_code', 'probability', 'reasoning']
                }
              },
              recommendations: {
                type: 'array',
                items: {
                  type: 'object',
                  properties: {
                    type: { type: 'string' },
                    recommendation: { type: 'string' },
                    urgency: { type: 'string' }
                  },
                  required: ['type', 'recommendation', 'urgency']
                }
              },
              rare_disease_alert: {
                type: 'object',
                properties: {
                  is_rare: { type: 'boolean' },
                  disease_name: { type: 'string' },
                  key_indicators: { type: 'array', items: { type: 'string' } },
                  specialist_referral: { type: 'string' }
                },
                required: ['is_rare']
              }
            },
            required: ['primary_diagnosis', 'differential_diagnoses', 'recommendations', 'rare_disease_alert'],
            additionalProperties: false
          }
        }
      }
    });

    return JSON.parse(response.choices[0].message.content);
  } catch (error) {
    console.error('Error generating diagnostic insights:', error);
    return {
      primary_diagnosis: {
        diagnosis: 'Unable to analyze',
        icd10_code: 'N/A',
        confidence: 0,
        rationale: 'Analysis unavailable at this time'
      },
      differential_diagnoses: [],
      recommendations: [],
      rare_disease_alert: { is_rare: false }
    };
  }
}

/**
 * Analyzes medical images and provides insights
 * @param {string} imageDescription - Description of the medical image
 * @param {string} imageType - Type of medical image (X-ray, MRI, etc.)
 * @returns {Promise<object>} Structured image analysis
 */
export async function analyzeMedicalImage(imageDescription, imageType) {
  try {
    const response = await openai.chat.completions.create({
      model: 'gpt-4o',
      messages: [
        {
          role: 'system',
          content: `You are a medical imaging AI specialist. Analyze medical images and provide detailed 
          insights about findings, abnormalities, and diagnostic significance. Focus on rare or unusual findings.`
        },
        {
          role: 'user',
          content: `Analyze this ${imageType} medical image: ${imageDescription}`
        }
      ],
      response_format: {
        type: 'json_schema',
        json_schema: {
          name: 'image_analysis',
          schema: {
            type: 'object',
            properties: {
              findings: {
                type: 'array',
                items: {
                  type: 'object',
                  properties: {
                    finding: { type: 'string' },
                    location: { type: 'string' },
                    severity: { type: 'string' },
                    clinical_significance: { type: 'string' }
                  },
                  required: ['finding', 'location', 'severity', 'clinical_significance']
                }
              },
              abnormalities: {
                type: 'array',
                items: {
                  type: 'object',
                  properties: {
                    abnormality: { type: 'string' },
                    description: { type: 'string' },
                    potential_causes: { type: 'array', items: { type: 'string' } }
                  },
                  required: ['abnormality', 'description', 'potential_causes']
                }
              },
              recommendations: {
                type: 'array',
                items: {
                  type: 'string'
                }
              },
              rare_findings: {
                type: 'object',
                properties: {
                  has_rare_findings: { type: 'boolean' },
                  findings: { type: 'array', items: { type: 'string' } },
                  specialist_consultation: { type: 'string' }
                },
                required: ['has_rare_findings']
              }
            },
            required: ['findings', 'abnormalities', 'recommendations', 'rare_findings'],
            additionalProperties: false
          }
        }
      }
    });

    return JSON.parse(response.choices[0].message.content);
  } catch (error) {
    console.error('Error analyzing medical image:', error);
    return {
      findings: [],
      abnormalities: [],
      recommendations: ['Unable to analyze image at this time'],
      rare_findings: { has_rare_findings: false }
    };
  }
}

/**
 * Generates treatment recommendations based on diagnosis
 * @param {string} diagnosis - Primary diagnosis
 * @param {object} patientInfo - Patient demographic and clinical info
 * @returns {Promise<object>} Structured treatment recommendations
 */
export async function generateTreatmentRecommendations(diagnosis, patientInfo) {
  try {
    const patientContext = `
      Diagnosis: ${diagnosis}
      Age Group: ${patientInfo.ageGroup || 'Not specified'}
      Sex: ${patientInfo.sex || 'Not specified'}
      Region: ${patientInfo.region || 'Not specified'}
      Additional Info: ${patientInfo.additionalInfo || 'None'}
    `;

    const response = await openai.chat.completions.create({
      model: 'gpt-4o',
      messages: [
        {
          role: 'system',
          content: `You are a clinical treatment specialist AI. Provide evidence-based treatment recommendations
          considering patient demographics, regional factors, and best practices. Include emergency protocols
          for urgent cases and specialized treatments for rare conditions.`
        },
        {
          role: 'user',
          content: `Provide treatment recommendations for: ${patientContext}`
        }
      ],
      response_format: {
        type: 'json_schema',
        json_schema: {
          name: 'treatment_recommendations',
          schema: {
            type: 'object',
            properties: {
              primary_treatment: {
                type: 'object',
                properties: {
                  treatment: { type: 'string' },
                  dosage: { type: 'string' },
                  duration: { type: 'string' },
                  monitoring: { type: 'string' }
                },
                required: ['treatment', 'dosage', 'duration', 'monitoring']
              },
              alternative_treatments: {
                type: 'array',
                items: {
                  type: 'object',
                  properties: {
                    treatment: { type: 'string' },
                    indication: { type: 'string' },
                    contraindications: { type: 'array', items: { type: 'string' } }
                  },
                  required: ['treatment', 'indication', 'contraindications']
                }
              },
              emergency_protocols: {
                type: 'array',
                items: {
                  type: 'object',
                  properties: {
                    trigger: { type: 'string' },
                    action: { type: 'string' },
                    urgency: { type: 'string' }
                  },
                  required: ['trigger', 'action', 'urgency']
                }
              },
              follow_up: {
                type: 'object',
                properties: {
                  timeline: { type: 'string' },
                  assessments: { type: 'array', items: { type: 'string' } },
                  specialist_referrals: { type: 'array', items: { type: 'string' } }
                },
                required: ['timeline', 'assessments', 'specialist_referrals']
              }
            },
            required: ['primary_treatment', 'alternative_treatments', 'emergency_protocols', 'follow_up'],
            additionalProperties: false
          }
        }
      }
    });

    return JSON.parse(response.choices[0].message.content);
  } catch (error) {
    console.error('Error generating treatment recommendations:', error);
    return {
      primary_treatment: {
        treatment: 'Unable to generate recommendations',
        dosage: 'N/A',
        duration: 'N/A',
        monitoring: 'Consult healthcare provider'
      },
      alternative_treatments: [],
      emergency_protocols: [],
      follow_up: {
        timeline: 'As directed by healthcare provider',
        assessments: [],
        specialist_referrals: []
      }
    };
  }
}

/**
 * Analyzes global health trends and patterns
 * @param {Array} caseData - Array of case data for pattern analysis
 * @returns {Promise<object>} Global health pattern analysis
 */
export async function analyzeGlobalHealthPatterns(caseData) {
  try {
    const casesSummary = caseData.map(case_item => ({
      region: case_item.region,
      symptoms: case_item.symptoms,
      timeline: case_item.timeline,
      demographics: case_item.demographics
    }));

    const response = await openai.chat.completions.create({
      model: 'gpt-4o',
      messages: [
        {
          role: 'system',
          content: `You are a global health epidemiologist AI. Analyze medical case patterns to identify 
          potential outbreaks, emerging diseases, geographic clusters, and public health concerns.
          Focus on unusual patterns that might indicate new or rare diseases.`
        },
        {
          role: 'user',
          content: `Analyze these medical cases for global health patterns: ${JSON.stringify(casesSummary)}`
        }
      ],
      response_format: {
        type: 'json_schema',
        json_schema: {
          name: 'global_health_analysis',
          schema: {
            type: 'object',
            properties: {
              geographic_clusters: {
                type: 'array',
                items: {
                  type: 'object',
                  properties: {
                    region: { type: 'string' },
                    case_count: { type: 'number' },
                    pattern_type: { type: 'string' },
                    significance: { type: 'string' }
                  },
                  required: ['region', 'case_count', 'pattern_type', 'significance']
                }
              },
              temporal_patterns: {
                type: 'array',
                items: {
                  type: 'object',
                  properties: {
                    time_period: { type: 'string' },
                    trend: { type: 'string' },
                    description: { type: 'string' }
                  },
                  required: ['time_period', 'trend', 'description']
                }
              },
              emerging_threats: {
                type: 'array',
                items: {
                  type: 'object',
                  properties: {
                    threat_type: { type: 'string' },
                    risk_level: { type: 'string' },
                    affected_regions: { type: 'array', items: { type: 'string' } },
                    recommendations: { type: 'array', items: { type: 'string' } }
                  },
                  required: ['threat_type', 'risk_level', 'affected_regions', 'recommendations']
                }
              },
              alerts: {
                type: 'array',
                items: {
                  type: 'object',
                  properties: {
                    alert_type: { type: 'string' },
                    severity: { type: 'string' },
                    message: { type: 'string' },
                    action_required: { type: 'boolean' }
                  },
                  required: ['alert_type', 'severity', 'message', 'action_required']
                }
              }
            },
            required: ['geographic_clusters', 'temporal_patterns', 'emerging_threats', 'alerts'],
            additionalProperties: false
          }
        }
      }
    });

    return JSON.parse(response.choices[0].message.content);
  } catch (error) {
    console.error('Error analyzing global health patterns:', error);
    return {
      geographic_clusters: [],
      temporal_patterns: [],
      emerging_threats: [],
      alerts: []
    };
  }
}

/**
 * Moderates medical content for safety and appropriateness
 * @param {string} content - Content to moderate
 * @returns {Promise<object>} Moderation results
 */
export async function moderateMedicalContent(content) {
  try {
    const response = await openai.moderations.create({
      model: 'text-moderation-latest',
      input: content,
    });

    return response.results[0];
  } catch (error) {
    console.error('Error moderating content:', error);
    return {
      flagged: false,
      categories: {},
      category_scores: {}
    };
  }
}
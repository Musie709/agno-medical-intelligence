import React from "react";
import { BrowserRouter, Routes as RouterRoutes, Route } from "react-router-dom";
import ScrollToTop from "components/ScrollToTop";
import ErrorBoundary from "components/ErrorBoundary";
// Add your imports here
import LoginRegistration from "pages/login-registration";
import DashboardOverview from "pages/dashboard-overview";
import CaseViewerDetails from "pages/case-viewer-details";
import PersonalCaseManagement from "pages/personal-case-management";
import UserProfileSettings from "pages/user-profile-settings";
import CaseSubmissionForm from "pages/case-submission-form";
import NotFound from "pages/NotFound";

const Routes = () => {
  return (
    <BrowserRouter>
      <ErrorBoundary>
      <ScrollToTop />
      <RouterRoutes>
        {/* Define your routes here */}
        <Route path="/" element={<DashboardOverview />} />
        <Route path="/login-registration" element={<LoginRegistration />} />
        <Route path="/dashboard-overview" element={<DashboardOverview />} />
        <Route path="/case-viewer-details" element={<CaseViewerDetails />} />
        <Route path="/personal-case-management" element={<PersonalCaseManagement />} />
        <Route path="/user-profile-settings" element={<UserProfileSettings />} />
        <Route path="/case-submission-form" element={<CaseSubmissionForm />} />
        <Route path="*" element={<NotFound />} />
      </RouterRoutes>
      </ErrorBoundary>
    </BrowserRouter>
  );
};

export default Routes;
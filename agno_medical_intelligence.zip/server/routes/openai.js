const express = require('express');
const router = express.Router();
const { Configuration, OpenAIApi } = require('openai');

// Middleware for JWT auth (placeholder, to be implemented)
const requireAuth = (req, res, next) => {
  // TODO: Implement JWT verification
  next();
};

const configuration = new Configuration({
  apiKey: process.env.OPENAI_API_KEY,
});
const openai = new OpenAIApi(configuration);

router.post('/', requireAuth, async (req, res) => {
  try {
    const { model, messages, ...rest } = req.body;
    const response = await openai.createChatCompletion({
      model,
      messages,
      ...rest,
    });
    res.json(response.data);
  } catch (error) {
    console.error('OpenAI API error:', error.message);
    res.status(500).json({ error: 'OpenAI API error', details: error.message });
  }
});

module.exports = router; 
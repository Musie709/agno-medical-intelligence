const express = require('express');
const cors = require('cors');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());

// Routes
app.use('/api/openai', require('./routes/openai'));
app.use('/api/auth', require('./routes/auth'));

app.get('/', (req, res) => {
  res.send('Agno Medical Intelligence Backend Running');
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
}); 